#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest.h>

#include "core/event_log.hpp"
#include "core/oms.hpp"

#include <condition_variable>
#include <filesystem>
#include <fstream>
#include <functional>
#include <map>
#include <mutex>
#include <nlohmann/json.hpp>
#include <optional>
#include <string>
#include <thread>
#include <vector>

namespace {

using namespace gateway;

/// Scripted in-memory ExchangeConnector: every verb dispatches to a
/// mutable std::function so tests can script outcomes per scenario.
class FakeConnector final : public ExchangeConnector
{
  public:
    std::function<Result<OrderPlacement>(const OrderRequest&)> place_impl =
        [](const OrderRequest& a_request) {
            return OrderPlacement{.client_order_id = a_request.client_order_id,
                                  .exchange_order_id = "ord-" + a_request.client_order_id};
        };
    std::function<Result<OrderPlacement>(const CancelRequest&)> cancel_impl =
        [](const CancelRequest& a_request) {
            return OrderPlacement{.client_order_id = a_request.client_order_id,
                                  .exchange_order_id = "ord-" + a_request.client_order_id};
        };
    std::function<Result<OrderPlacement>(const AmendRequest&)> amend_impl =
        [](const AmendRequest& a_request) {
            return OrderPlacement{.client_order_id = a_request.client_order_id,
                                  .exchange_order_id = "ord-" + a_request.client_order_id};
        };
    std::function<Result<std::optional<OrderSnapshot>>(const OrderQuery&)> get_impl =
        [](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
        return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{std::nullopt}};
    };
    std::function<Result<std::vector<OrderSnapshot>>()> open_impl =
        []() -> Result<std::vector<OrderSnapshot>> { return std::vector<OrderSnapshot>{}; };
    std::function<Result<std::string>(const std::string&)> price_impl =
        [](const std::string& a_symbol) -> Result<std::string> {
        return "fake-" + a_symbol + "-price";
    };

    std::vector<OrderRequest> placed;
    std::vector<CancelRequest> cancels;
    std::vector<AmendRequest> amends;
    std::vector<std::string> price_queries;

    [[nodiscard]] auto place_order(const OrderRequest& a_request) -> Result<OrderPlacement> override
    {
        placed.push_back(a_request);
        return place_impl(a_request);
    }
    [[nodiscard]] auto
    cancel_order(const CancelRequest& a_request) -> Result<OrderPlacement> override
    {
        cancels.push_back(a_request);
        return cancel_impl(a_request);
    }
    [[nodiscard]] auto amend_order(const AmendRequest& a_request) -> Result<OrderPlacement> override
    {
        amends.push_back(a_request);
        return amend_impl(a_request);
    }
    [[nodiscard]] auto
    get_order(const OrderQuery& a_query) -> Result<std::optional<OrderSnapshot>> override
    {
        return get_impl(a_query);
    }
    [[nodiscard]] auto get_open_orders() -> Result<std::vector<OrderSnapshot>> override
    {
        return open_impl();
    }
    [[nodiscard]] auto get_price(const std::string& a_instrument_id) -> Result<std::string> override
    {
        price_queries.push_back(a_instrument_id);
        return price_impl(a_instrument_id);
    }
    void
    set_execution_report_handler(std::function<void(const ExecutionReport&)> a_handler) override
    {
        report_handler = std::move(a_handler);
    }
    void set_connectivity_handler(std::function<void(bool)> a_handler) override
    {
        connectivity_handler = std::move(a_handler);
    }
    void start() override {}
    void stop() override {}

    std::function<void(const ExecutionReport&)> report_handler;
    std::function<void(bool)> connectivity_handler;
};

auto temp_log_path(const char* a_name) -> std::filesystem::path
{
    return std::filesystem::temp_directory_path() /
           ("gateway_oms_test_" + std::string(a_name) + ".jsonl");
}

auto buy_request(const std::string& a_id = "gw1", const std::string& a_qty = "1") -> OrderRequest
{
    return OrderRequest{.client_order_id = a_id,
                        .instrument_id = "BTC-USDT",
                        .side = Side::Buy,
                        .type = OrderType::Limit,
                        .price = "50000",
                        .quantity = a_qty,
                        .time_in_force = ""};
}

auto report(const std::string& a_id, OrderState a_state, const std::string& a_filled,
            const std::string& a_avg = "") -> ExecutionReport
{
    return ExecutionReport{.client_order_id = a_id,
                           .exchange_order_id = "ord-" + a_id,
                           .state = a_state,
                           .side = Side::Buy,
                           .filled_quantity = a_filled,
                           .average_fill_price = a_avg};
}

auto risk_with_position(const std::string& a_max_position) -> RiskConfig
{
    auto parsed = risk_config_from_json(nlohmann::json::parse(
        R"({"instruments":{"BTC-USDT":{"maxPosition":")" + a_max_position + R"("}}})"));
    REQUIRE(parsed.is_ok());
    return parsed.value();
}

// ---------------------------------------------------------------- place ----

TEST_CASE("place records the accepted order and replays it idempotently")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    const auto first = oms.place(buy_request());
    REQUIRE(first.is_ok());
    CHECK_FALSE(first.value().replayed);
    CHECK(first.value().record.state == OrderState::Live);
    CHECK(first.value().record.exchange_order_id == "ord-gw1");
    CHECK(first.value().record.time_in_force == "GTC");
    REQUIRE(connector.placed.size() == 1);

    // strict idempotency: same clientOrderId replays the recorded outcome
    // without touching the venue again
    const auto second = oms.place(buy_request());
    REQUIRE(second.is_ok());
    CHECK(second.value().replayed);
    CHECK(second.value().record.exchange_order_id == first.value().record.exchange_order_id);
    REQUIRE(connector.placed.size() == 1);

    // even a DIFFERENT payload with the same clientOrderId replays (the
    // clientOrderId is the idempotency key)
    auto other = buy_request();
    other.quantity = "999";
    const auto third = oms.place(other);
    REQUIRE(third.is_ok());
    CHECK(third.value().replayed);
    REQUIRE(connector.placed.size() == 1);
}

TEST_CASE("place after a terminal outcome still replays the recorded outcome")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    REQUIRE(oms.place(buy_request()).is_ok());
    REQUIRE(oms.cancel("gw1").is_ok());

    const auto replayed = oms.place(buy_request());
    REQUIRE(replayed.is_ok());
    CHECK(replayed.value().replayed);
    CHECK(replayed.value().record.state == OrderState::Canceled);
    REQUIRE(connector.placed.size() == 1); // never re-sent
}

TEST_CASE("risk rejections are recorded and replayed")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, risk_with_position("1")};

    const auto rejected = oms.place(buy_request("gw1", "5"));
    REQUIRE_FALSE(rejected.is_ok());
    CHECK(rejected.error().code == "risk_max_position");
    REQUIRE(connector.placed.empty()); // never routed to the venue

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Rejected);
    REQUIRE(record.value().rejection.has_value());
    CHECK(record.value().rejection->code == "risk_max_position");

    // retrying the same clientOrderId replays the same rejection
    const auto replayed = oms.place(buy_request("gw1", "5"));
    REQUIRE_FALSE(replayed.is_ok());
    CHECK(replayed.error().code == "risk_max_position");
    REQUIRE(connector.placed.empty());
}

TEST_CASE("risk_config returns the configured limits (read-only surface)")
{
    FakeConnector connector;
    const auto risk = risk_config_from_json(nlohmann::json::parse(
        R"({"default":{"maxQty":"10","maxNotional":"1000000","maxPosition":"10"},)"
        R"("instruments":{"BTC-USDT":{"maxQty":"5","maxNotional":"","maxPosition":"2"}}})"));
    REQUIRE(risk.is_ok());
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, risk.value()};

    const auto config = oms.risk_config();
    REQUIRE(config.defaults.has_value());
    CHECK(config.defaults->max_qty == "10");
    CHECK(config.defaults->max_notional == "1000000");
    CHECK(config.defaults->max_position == "10");
    REQUIRE(config.instruments.size() == 1);
    const auto it = config.instruments.find("BTC-USDT");
    REQUIRE(it != config.instruments.end());
    CHECK(it->second.max_qty == "5");
    CHECK(it->second.max_notional == ""); // empty = check disabled
    CHECK(it->second.max_position == "2");

    // the snapshot resolves limits exactly like the engine does
    const auto limits = config.limits_for("BTC-USDT");
    REQUIRE(limits.has_value());
    CHECK(limits->max_qty == "5");
    const auto fallback = config.limits_for("ETH-USDT"); // no entry -> defaults
    REQUIRE(fallback.has_value());
    CHECK(fallback->max_qty == "10");
}

TEST_CASE("risk_config with no limits configured is empty")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    const auto config = oms.risk_config();
    CHECK_FALSE(config.defaults.has_value());
    CHECK(config.instruments.empty());
    CHECK(config.limits_for("BTC-USDT") == std::nullopt);
}

TEST_CASE("definitive venue rejections are recorded and replayed")
{
    FakeConnector connector;
    connector.place_impl = [](const OrderRequest&) -> Result<OrderPlacement> {
        return Error{"venue:51001", "Instrument ID does not exist"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    const auto rejected = oms.place(buy_request());
    REQUIRE_FALSE(rejected.is_ok());
    CHECK(rejected.error().code == "venue:51001");

    const auto replayed = oms.place(buy_request());
    REQUIRE_FALSE(replayed.is_ok());
    CHECK(replayed.error().code == "venue:51001");
    REQUIRE(connector.placed.size() == 1); // the venue saw it exactly once
    CHECK(oms.query("gw1").value().state == OrderState::Rejected);
}

TEST_CASE("transport-unresolved places stay pending until reconciled")
{
    FakeConnector connector;
    connector.place_impl = [](const OrderRequest&) -> Result<OrderPlacement> {
        return Error{"transport", "unresolved"};
    };
    const auto path = temp_log_path("transport_pending");
    std::filesystem::remove(path);
    EventLog log{path};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};

    const auto failed = oms.place(buy_request());
    REQUIRE_FALSE(failed.is_ok());
    CHECK(failed.error().code == "transport");

    // the intent is visible and queryable: "we tried this id"
    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Pending);
    CHECK(record.value().exchange_order_id.empty());
    CHECK(record.value().quantity == "1");

    // retries replay the pending record; the venue is never re-sent
    // (the adapter already resolved as far as it could)
    const auto retried = oms.place(buy_request());
    REQUIRE(retried.is_ok());
    CHECK(retried.value().replayed);
    CHECK(retried.value().record.state == OrderState::Pending);
    REQUIRE(connector.placed.size() == 1);

    // cancel/amend of the unacked order are gateway-side rejections
    const auto cancel = oms.cancel("gw1");
    REQUIRE_FALSE(cancel.is_ok());
    CHECK(cancel.error().code == "order_pending");
    const auto amend =
        oms.amend(AmendCommand{"gw1", std::optional<std::string>{"1"}, std::nullopt});
    REQUIRE_FALSE(amend.is_ok());
    CHECK(amend.error().code == "order_pending");
    CHECK(connector.cancels.empty());
    CHECK(connector.amends.empty());

    // the pending intent survives a restart (place_submitted replay)
    OrderManagementSystem restarted{{{"okx", &connector}}, &log, RiskConfig{}};
    REQUIRE(restarted.load_from_log().is_ok());
    const auto recovered = restarted.query("gw1");
    REQUIRE(recovered.is_ok());
    CHECK(recovered.value().state == OrderState::Pending);

    // conclusive absence at reconciliation -> deterministic Rejected
    const auto reconcile_report = oms.reconcile();
    CHECK(reconcile_report.absent_rejected == 1);
    const auto rejected = oms.query("gw1");
    REQUIRE(rejected.is_ok());
    CHECK(rejected.value().state == OrderState::Rejected);
    REQUIRE(rejected.value().rejection.has_value());
    CHECK(rejected.value().rejection->code == "venue_absent");

    // ...and retries now replay the recorded rejection
    const auto replayed = oms.place(buy_request());
    REQUIRE_FALSE(replayed.is_ok());
    CHECK(replayed.error().code == "venue_absent");
    REQUIRE(connector.placed.size() == 1);
}

TEST_CASE("an execution report can resolve a transport-unresolved pending order")
{
    FakeConnector connector;
    connector.place_impl = [](const OrderRequest&) -> Result<OrderPlacement> {
        return Error{"transport", "unresolved"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE_FALSE(oms.place(buy_request()).is_ok());

    // the venue feed later proves the order actually landed and filled:
    // the first applied observation jumps Pending -> PartiallyFilled
    oms.on_execution_report(report("gw1", OrderState::PartiallyFilled, "0.4", "49999.5"));
    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::PartiallyFilled);
    CHECK(record.value().filled_quantity == "0.4");

    // resolved orders behave normally again (cancel is a venue call)
    const auto canceled = oms.cancel("gw1");
    REQUIRE(canceled.is_ok());
    CHECK(canceled.value().state == OrderState::Canceled);
    REQUIRE(connector.cancels.size() == 1);
}

TEST_CASE("execution reports racing an in-flight place are buffered and applied")
{
    // On WS-API venues (Binance) the executionReport frame can precede the
    // order.place response, and the venue feed thread applies it while the
    // place's venue call is still open. Regression for the lock-scope
    // refactor: the report must neither deadlock, nor be lost, nor land
    // before the place_accepted event (replay-correct log order).
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    connector.place_impl = [&oms](const OrderRequest& a_request) -> Result<OrderPlacement> {
        oms.on_execution_report(
            report(a_request.client_order_id, OrderState::Filled, "1", "50000"));
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-" + a_request.client_order_id};
    };

    const auto outcome = oms.place(buy_request());
    REQUIRE(outcome.is_ok());
    CHECK(outcome.value().record.state == OrderState::Filled);
    CHECK(outcome.value().record.filled_quantity == "1");
    CHECK(outcome.value().record.average_fill_price == "50000");
    CHECK(outcome.value().record.exchange_order_id == "ord-gw1");
    CHECK_FALSE(outcome.value().replayed);
}

TEST_CASE("a place is born pending and visible before the venue ack")
{
    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.place_impl = [&oms_ptr](const OrderRequest& a_request) -> Result<OrderPlacement> {
        // during the open venue call the registry already knows the
        // intent — GET returns a working view of "we tried this id"
        const auto mid_flight = oms_ptr->query(a_request.client_order_id);
        REQUIRE(mid_flight.is_ok());
        CHECK(mid_flight.value().state == OrderState::Pending);
        CHECK(mid_flight.value().exchange_order_id.empty());

        // a report racing the open venue call is buffered, not applied:
        // place_accepted must precede state events in the log
        oms_ptr->on_execution_report(
            report(a_request.client_order_id, OrderState::PartiallyFilled, "0.4", "49999.5"));
        const auto still_pending = oms_ptr->query(a_request.client_order_id);
        REQUIRE(still_pending.is_ok());
        CHECK(still_pending.value().state == OrderState::Pending);

        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-" + a_request.client_order_id};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms_ptr = &oms;

    const auto outcome = oms.place(buy_request());
    REQUIRE(outcome.is_ok());
    CHECK_FALSE(outcome.value().replayed);
    // ack + drained report: pending -> live -> partially_filled
    CHECK(outcome.value().record.state == OrderState::PartiallyFilled);
    CHECK(outcome.value().record.filled_quantity == "0.4");
    CHECK(outcome.value().record.exchange_order_id == "ord-gw1");
}

TEST_CASE("a duplicate place while the venue call is in flight replays the pending record")
{
    FakeConnector connector;
    std::mutex mutex;
    std::condition_variable cv;
    int venue_entries = 0;
    bool release = false;
    connector.place_impl = [&](const OrderRequest& a_request) -> Result<OrderPlacement> {
        {
            const std::lock_guard lock(mutex);
            ++venue_entries;
            cv.notify_all();
        }
        std::unique_lock lock(mutex);
        cv.wait(lock, [&] { return release; }); // hold the venue call open
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-" + a_request.client_order_id};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    bool first_ok = false;
    std::thread first([&] {
        const auto outcome = oms.place(buy_request());
        first_ok = outcome.is_ok() && !outcome.value().replayed &&
                   outcome.value().record.state == OrderState::Live;
    });
    {
        std::unique_lock lock(mutex);
        cv.wait(lock, [&] { return venue_entries == 1; });
    }
    const auto duplicate = oms.place(buy_request()); // same id, venue call open
    REQUIRE(duplicate.is_ok());
    CHECK(duplicate.value().replayed);
    // honest about the unacked state — never an optimistic 201 live
    CHECK(duplicate.value().record.state == OrderState::Pending);
    CHECK(duplicate.value().record.exchange_order_id.empty());
    {
        const std::lock_guard lock(mutex);
        release = true;
        cv.notify_all();
    }
    first.join();
    CHECK(first_ok);
    CHECK(connector.placed.size() == 1); // exactly one venue request was sent

    const auto settled = oms.query("gw1");
    REQUIRE(settled.is_ok());
    CHECK(settled.value().state == OrderState::Live);
    CHECK(settled.value().exchange_order_id == "ord-gw1");
}

TEST_CASE("pending orders count toward the projected position")
{
    FakeConnector connector;
    std::mutex mutex;
    std::condition_variable cv;
    int venue_entries = 0;
    bool release = false;
    connector.place_impl = [&](const OrderRequest& a_request) -> Result<OrderPlacement> {
        {
            const std::lock_guard lock(mutex);
            ++venue_entries;
            cv.notify_all();
        }
        std::unique_lock lock(mutex);
        cv.wait(lock, [&] { return release; });
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-" + a_request.client_order_id};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, risk_with_position("1")};

    std::thread first([&] {
        const auto outcome = oms.place(buy_request("b1", "1"));
        REQUIRE(outcome.is_ok());
    });
    {
        std::unique_lock lock(mutex);
        cv.wait(lock, [&] { return venue_entries == 1; }); // b1 pending in-flight
    }
    // b1's venue call is still open, but it is registry exposure: a
    // second buy breaches the position limit without any venue call
    const auto over = oms.place(buy_request("b2", "0.5"));
    REQUIRE_FALSE(over.is_ok());
    CHECK(over.error().code == "risk_max_position");
    CHECK(connector.placed.size() == 1);

    {
        const std::lock_guard lock(mutex);
        release = true;
        cv.notify_all();
    }
    first.join();
    CHECK(oms.query("b1").value().state == OrderState::Live);
}

TEST_CASE("a place whose place_submitted cannot persist is never sent")
{
    FakeConnector connector;
    EventLog log{std::filesystem::temp_directory_path() / "gateway_no_such_dir" / "x.jsonl"};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};

    const auto outcome = oms.place(buy_request());
    REQUIRE_FALSE(outcome.is_ok());
    CHECK(outcome.error().code == "persistence");
    // nothing sent, nothing recorded: the clientOrderId is still free
    CHECK(connector.placed.empty());
    CHECK(oms.stats().known_orders == 0);
    CHECK(oms.stats().log_write_failures == 1);
    CHECK_FALSE(oms.query("gw1").is_ok());
}

// ------------------------------------------------------- execution feeds ----

TEST_CASE("execution reports advance state and dedupe exactly")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    const auto partial = report("gw1", OrderState::PartiallyFilled, "0.4", "49999.5");
    oms.on_execution_report(partial);
    oms.on_execution_report(partial); // exact duplicate

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::PartiallyFilled);
    CHECK(record.value().filled_quantity == "0.4");
    CHECK(record.value().average_fill_price == "49999.5");
    CHECK(oms.stats().reports_applied == 1);
    CHECK(oms.stats().reports_stale == 1);
}

TEST_CASE("out-of-order reports never regress state or fills")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    oms.on_execution_report(report("gw1", OrderState::PartiallyFilled, "0.4", "49999.5"));
    // an older "live, nothing filled" report arrives late
    oms.on_execution_report(report("gw1", OrderState::Live, "0"));

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::PartiallyFilled);
    CHECK(record.value().filled_quantity == "0.4");
    CHECK(oms.stats().reports_stale == 1);
}

TEST_CASE("REST-vs-WS race: fill report wins over later stale snapshot data")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    // WS delivers the fill...
    oms.on_execution_report(report("gw1", OrderState::Filled, "1", "50000"));
    // ...then a REST snapshot taken BEFORE the fill is applied (a report
    // with the same information would race identically)
    oms.on_execution_report(report("gw1", OrderState::Live, "0"));

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Filled);
    CHECK(record.value().filled_quantity == "1");
}

TEST_CASE("terminal orders ignore state regression but keep late fill data")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    oms.on_execution_report(report("gw1", OrderState::Canceled, "0"));
    oms.on_execution_report(report("gw1", OrderState::Live, "1")); // illegal: Canceled -> Live

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Canceled); // state never regressed
    CHECK(record.value().filled_quantity == "1");        // fill information is kept
}

TEST_CASE("reports for unknown orders are counted, not applied")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms.on_execution_report(report("ghost", OrderState::Filled, "1"));
    CHECK(oms.stats().reports_unknown == 1);
    CHECK_FALSE(oms.query("ghost").is_ok());
}

TEST_CASE("late fill data still lands after the state went terminal")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    // venue canceled a partially filled order; the fill report races in
    // after the cancel snapshot
    oms.on_execution_report(report("gw1", OrderState::Canceled, "0.2", "49999"));
    oms.on_execution_report(report("gw1", OrderState::PartiallyFilled, "0.2", "49999"));

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Canceled); // state kept
    CHECK(record.value().filled_quantity == "0.2");      // fill kept
}

// -------------------------------------------------------- cancel / amend ----

TEST_CASE("cancelReplace amends: superseded legs never terminalize the live replacement")
{
    // Binance-style amend: the venue cancels the old order (own report)
    // and places a replacement (NEW exchangeOrderId) under the SAME
    // clientOrderId. The old leg's CANCELED racing or following the amend
    // must not terminalize the record; the replacement's reports drive it.
    FakeConnector connector;
    int amend_venue_id = 0;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.amend_impl = [&amend_venue_id, &oms_ptr](const AmendRequest& a_request) {
        ++amend_venue_id;
        // the replaced leg's CANCELED lands while the venue call is open
        // (after validation, before the outcome applies)
        oms_ptr->on_execution_report(report("gw1", OrderState::Canceled, "0"));
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id =
                                  "ord-replacement-" + std::to_string(amend_venue_id)};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms_ptr = &oms;
    REQUIRE(oms.place(buy_request()).is_ok()); // exchangeOrderId ord-gw1

    const auto amended = oms.amend(AmendCommand{"gw1", "51000", std::nullopt});
    REQUIRE(amended.is_ok());
    CHECK(amended.value().state == OrderState::Live); // un-canceled: replacement is live
    CHECK(amended.value().exchange_order_id == "ord-replacement-1");

    // a LATE duplicate of the old leg's CANCELED (superseded id ord-gw1):
    // counted as stale for lifecycle purposes, fills still apply
    oms.on_execution_report(report("gw1", OrderState::Canceled, "0"));
    CHECK(oms.query("gw1").value().state == OrderState::Live);

    // the second amend still works (the record was never terminalized)
    const auto amended_again = oms.amend(AmendCommand{"gw1", "52000", std::nullopt});
    REQUIRE(amended_again.is_ok());
    CHECK(amended_again.value().exchange_order_id == "ord-replacement-2");

    // the replacement fills on its own id
    oms.on_execution_report(ExecutionReport{.client_order_id = "gw1",
                                            .exchange_order_id = "ord-replacement-2",
                                            .state = OrderState::Filled,
                                            .side = Side::Buy,
                                            .filled_quantity = "1",
                                            .average_fill_price = "51000"});
    const auto filled = oms.query("gw1");
    REQUIRE(filled.is_ok());
    CHECK(filled.value().state == OrderState::Filled);
    CHECK(filled.value().filled_quantity == "1");
}

TEST_CASE("cancel is idempotent and rejects terminal orders clearly")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    const auto missing = oms.cancel("gw1");
    REQUIRE_FALSE(missing.is_ok());
    CHECK(missing.error().code == "not_found");

    REQUIRE(oms.place(buy_request()).is_ok());
    const auto canceled = oms.cancel("gw1");
    REQUIRE(canceled.is_ok());
    CHECK(canceled.value().state == OrderState::Canceled);

    const auto again = oms.cancel("gw1");
    REQUIRE(again.is_ok());
    CHECK(again.value().state == OrderState::Canceled);
    REQUIRE(connector.cancels.size() == 1); // venue asked once

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Canceled);
}

TEST_CASE("cancel of a filled order is order_terminal, not a venue call")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());
    oms.on_execution_report(report("gw1", OrderState::Filled, "1"));

    const auto result = oms.cancel("gw1");
    REQUIRE_FALSE(result.is_ok());
    CHECK(result.error().code == "order_terminal");
    CHECK(connector.cancels.empty());
}

TEST_CASE("amend updates the record after the venue accepts")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    const auto amended = oms.amend(
        AmendCommand{"gw1", std::optional<std::string>{"51000"}, std::optional<std::string>{"2"}});
    REQUIRE(amended.is_ok());
    CHECK(amended.value().price == "51000");
    CHECK(amended.value().quantity == "2");
    REQUIRE(connector.amends.size() == 1);
    CHECK(connector.amends.front().new_price.value() == "51000");

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().price == "51000");
    CHECK(record.value().quantity == "2");
}

TEST_CASE("amend validates its inputs and the order's liveness")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    const auto nothing = oms.amend(AmendCommand{"gw1", std::nullopt, std::nullopt});
    REQUIRE_FALSE(nothing.is_ok());
    CHECK(nothing.error().code == "protocol");

    const auto missing =
        oms.amend(AmendCommand{"ghost", std::optional<std::string>{"1"}, std::nullopt});
    REQUIRE_FALSE(missing.is_ok());
    CHECK(missing.error().code == "not_found");

    REQUIRE(oms.place(buy_request()).is_ok());
    REQUIRE(oms.cancel("gw1").is_ok());
    const auto terminal =
        oms.amend(AmendCommand{"gw1", std::optional<std::string>{"1"}, std::nullopt});
    REQUIRE_FALSE(terminal.is_ok());
    CHECK(terminal.error().code == "order_terminal");
    CHECK(connector.amends.empty());
}

TEST_CASE("amends re-run risk against the projected position")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, risk_with_position("1")};

    REQUIRE(oms.place(buy_request("gw1", "1")).is_ok());
    const auto grow = oms.amend(AmendCommand{"gw1", std::nullopt, std::optional<std::string>{"3"}});
    REQUIRE_FALSE(grow.is_ok());
    CHECK(grow.error().code == "risk_max_position");
    CHECK(connector.amends.empty());

    const auto shrink =
        oms.amend(AmendCommand{"gw1", std::nullopt, std::optional<std::string>{"0.5"}});
    REQUIRE(shrink.is_ok());
    CHECK(shrink.value().quantity == "0.5");
}

TEST_CASE("hedged buy+sell exposure nets out in the position projection")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, risk_with_position("1")};

    REQUIRE(oms.place(buy_request("b1", "1")).is_ok());
    auto sell = buy_request("s1", "1");
    sell.side = Side::Sell;
    const auto hedged = oms.place(sell);
    REQUIRE(hedged.is_ok()); // +1 buy and -1 sell net to zero

    auto extra = buy_request("b2", "2");
    const auto over = oms.place(extra);
    REQUIRE_FALSE(over.is_ok());
    CHECK(over.error().code == "risk_max_position"); // net 0 + 2 breaches the limit
}

// ---------------------------------------------------------- persistence ----

TEST_CASE("a full lifecycle persists and replays into an identical registry")
{
    const auto path = temp_log_path("lifecycle");
    std::filesystem::remove(path);

    std::string exchange_order_id;
    {
        FakeConnector connector;
        EventLog log{path};
        OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};

        REQUIRE(oms.place(buy_request("gw1", "1")).is_ok());
        oms.on_execution_report(report("gw1", OrderState::PartiallyFilled, "0.4", "49999.5"));
        REQUIRE(oms.amend(AmendCommand{"gw1", std::optional<std::string>{"48000"},
                                       std::optional<std::string>{"2"}})
                    .is_ok());
        oms.on_execution_report(report("gw1", OrderState::Filled, "2", "48100"));
        exchange_order_id = oms.query("gw1").value().exchange_order_id;
    }

    FakeConnector connector;
    EventLog log{path};
    OrderManagementSystem recovered{{{"okx", &connector}}, &log, RiskConfig{}};
    const auto stats = recovered.load_from_log();
    REQUIRE(stats.is_ok());
    CHECK(stats.value().events > 0);
    CHECK_FALSE(stats.value().tail_truncated);

    const auto after = recovered.query("gw1");
    REQUIRE(after.is_ok());
    CHECK(after.value().state == OrderState::Filled);
    CHECK(after.value().filled_quantity == "2");
    CHECK(after.value().average_fill_price == "48100");
    CHECK(after.value().price == "48000");
    CHECK(after.value().quantity == "2");
    CHECK(after.value().side == Side::Buy);
    CHECK(after.value().exchange_order_id == exchange_order_id);
}

TEST_CASE("rejections persist and replay as deterministic rejections")
{
    const auto path = temp_log_path("rejected");
    std::filesystem::remove(path);

    {
        FakeConnector connector;
        EventLog log{path};
        OrderManagementSystem oms{{{"okx", &connector}}, &log, risk_with_position("1")};
        const auto rejected = oms.place(buy_request("gw1", "5"));
        REQUIRE_FALSE(rejected.is_ok());
    }

    FakeConnector connector;
    EventLog log{path};
    OrderManagementSystem recovered{{{"okx", &connector}}, &log, RiskConfig{}};
    REQUIRE(recovered.load_from_log().is_ok());

    const auto replayed = recovered.place(buy_request("gw1", "5"));
    REQUIRE_FALSE(replayed.is_ok());
    CHECK(replayed.error().code == "risk_max_position");
    CHECK(connector.placed.empty());
}

TEST_CASE("load_from_log survives a torn tail")
{
    const auto path = temp_log_path("torn");
    std::filesystem::remove(path);
    {
        FakeConnector connector;
        EventLog log{path};
        OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
        REQUIRE(oms.place(buy_request("gw1")).is_ok());
    }
    {
        std::ofstream file(path, std::ios::app | std::ios::binary);
        file << R"({"type":"state","clientOrderId":"gw1","sta)";
    }

    FakeConnector connector;
    EventLog log{path};
    OrderManagementSystem recovered{{{"okx", &connector}}, &log, RiskConfig{}};
    const auto stats = recovered.load_from_log();
    REQUIRE(stats.is_ok());
    CHECK(stats.value().tail_truncated);
    const auto record = recovered.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Live);
}

TEST_CASE("a corrupt mid-file log fails load_from_log")
{
    const auto path = temp_log_path("corrupt");
    std::filesystem::remove(path);
    {
        FakeConnector connector;
        EventLog log{path};
        OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
        REQUIRE(oms.place(buy_request("gw1")).is_ok());
    }
    {
        std::ofstream file(path, std::ios::app | std::ios::binary);
        file << "garbage not json\n";
    }

    FakeConnector connector;
    EventLog log{path};
    OrderManagementSystem recovered{{{"okx", &connector}}, &log, RiskConfig{}};
    const auto stats = recovered.load_from_log();
    REQUIRE_FALSE(stats.is_ok());
    CHECK(stats.error().code == "persistence");
}

// ----------------------------------------------------------- reconcile ----

TEST_CASE("reconcile adopts venue-live orders missing from the registry")
{
    const auto path = temp_log_path("adopt");
    std::filesystem::remove(path);

    FakeConnector connector;
    const OrderSnapshot venue_order{.client_order_id = "venueonly",
                                    .exchange_order_id = "ord-77",
                                    .instrument_id = "BTC-USDT",
                                    .state = OrderState::PartiallyFilled,
                                    .side = Side::Sell,
                                    .type = OrderType::Limit,
                                    .price = "49000",
                                    .quantity = "3",
                                    .filled_quantity = "1",
                                    .average_fill_price = "48999"};
    connector.open_impl = [&venue_order]() -> Result<std::vector<OrderSnapshot>> {
        return std::vector<OrderSnapshot>{venue_order};
    };
    connector.get_impl =
        [&venue_order](const OrderQuery& a_query) -> Result<std::optional<OrderSnapshot>> {
        if (a_query.client_order_id == "venueonly") {
            return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{venue_order}};
        }
        return Error{"venue:51603", "Order does not exist"};
    };
    EventLog log{path};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};

    const auto report = oms.reconcile();
    CHECK(report.adopted == 1);

    const auto record = oms.query("venueonly");
    REQUIRE(record.is_ok());
    CHECK(record.value().adopted);
    CHECK(record.value().state == OrderState::PartiallyFilled);
    CHECK(record.value().side == Side::Sell);
    CHECK(record.value().filled_quantity == "1");

    // the adoption itself persists: a restart learns it from the log
    OrderManagementSystem restarted{{{"okx", &connector}}, &log, RiskConfig{}};
    REQUIRE(restarted.load_from_log().is_ok());
    const auto replayed = restarted.query("venueonly");
    REQUIRE(replayed.is_ok());
    CHECK(replayed.value().adopted);
    CHECK(replayed.value().state == OrderState::PartiallyFilled);
}

TEST_CASE("reconcile resolves, rejects-absent, and keeps live entries")
{
    FakeConnector connector;
    EventLog log{temp_log_path("resolve")};
    std::filesystem::remove(log.path());
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};

    REQUIRE(oms.place(buy_request("filled1")).is_ok());
    REQUIRE(oms.place(buy_request("absent1")).is_ok());
    REQUIRE(oms.place(buy_request("stale1")).is_ok());

    connector.get_impl = [](const OrderQuery& a_query) -> Result<std::optional<OrderSnapshot>> {
        if (a_query.client_order_id == "filled1") {
            return Result<std::optional<OrderSnapshot>>{
                std::optional<OrderSnapshot>{OrderSnapshot{.client_order_id = "filled1",
                                                           .exchange_order_id = "ord-filled1",
                                                           .instrument_id = "BTC-USDT",
                                                           .state = OrderState::Filled,
                                                           .side = Side::Buy,
                                                           .type = OrderType::Limit,
                                                           .price = "50000",
                                                           .quantity = "1",
                                                           .filled_quantity = "1",
                                                           .average_fill_price = "50000"}}};
        }
        if (a_query.client_order_id == "absent1") {
            return Error{"venue:51603", "Order does not exist"};
        }
        return Error{"transport", "venue unreachable"};
    };

    const auto report = oms.reconcile();
    CHECK(report.terminal_resolved == 1);
    CHECK(report.absent_rejected == 1);
    CHECK(report.unresolved == 1);

    const auto filled = oms.query("filled1");
    REQUIRE(filled.is_ok());
    CHECK(filled.value().state == OrderState::Filled);

    const auto absent = oms.query("absent1");
    REQUIRE(absent.is_ok());
    CHECK(absent.value().state == OrderState::Rejected);
    REQUIRE(absent.value().rejection.has_value());
    CHECK(absent.value().rejection->code == "venue_absent");

    const auto stale = oms.query("stale1");
    REQUIRE(stale.is_ok());
    CHECK(stale.value().state == OrderState::Live); // kept, not guessed
}

TEST_CASE("reconcile tolerates a failing pending listing")
{
    FakeConnector connector;
    connector.open_impl = []() -> Result<std::vector<OrderSnapshot>> {
        return Error{"transport", "orders-pending unreachable"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    connector.get_impl = [](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
        return Error{"transport", "down"};
    };
    const auto report = oms.reconcile();
    CHECK(report.pending_listing_failed);
    CHECK(report.unresolved == 1);
    CHECK(oms.query("gw1").value().state == OrderState::Live);
}

// ------------------------------------------------------- restart drill ----

TEST_CASE("restart drill: replay + reconcile reconstructs in-flight fills")
{
    const auto path = temp_log_path("drill");
    std::filesystem::remove(path);

    // instance 1: place an order, then "crash" before seeing any fill
    {
        FakeConnector connector;
        EventLog log{path};
        OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
        REQUIRE(oms.place(buy_request("gw1", "2")).is_ok());
    }

    // while down, the venue partially fills the order and knows it live
    FakeConnector connector;
    const OrderSnapshot venue_state{.client_order_id = "gw1",
                                    .exchange_order_id = "ord-gw1",
                                    .instrument_id = "BTC-USDT",
                                    .state = OrderState::PartiallyFilled,
                                    .side = Side::Buy,
                                    .type = OrderType::Limit,
                                    .price = "50000",
                                    .quantity = "2",
                                    .filled_quantity = "0.7",
                                    .average_fill_price = "49999.5"};
    connector.open_impl = [&venue_state]() -> Result<std::vector<OrderSnapshot>> {
        return std::vector<OrderSnapshot>{venue_state};
    };
    connector.get_impl =
        [&venue_state](const OrderQuery& a_query) -> Result<std::optional<OrderSnapshot>> {
        if (a_query.client_order_id == "gw1") {
            return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{venue_state}};
        }
        return Error{"venue:51603", "Order does not exist"};
    };

    // instance 2: replay the log, then reconcile with the venue
    EventLog log{path};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
    REQUIRE(oms.load_from_log().is_ok());
    const auto report = oms.reconcile();
    CHECK(report.updated >= 1);

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::PartiallyFilled);
    CHECK(record.value().filled_quantity == "0.7");
    CHECK(record.value().average_fill_price == "49999.5");
    CHECK_FALSE(record.value().adopted);

    // strict idempotency survived the restart
    const auto replayed = oms.place(buy_request("gw1", "2"));
    REQUIRE(replayed.is_ok());
    CHECK(replayed.value().replayed);
    CHECK(connector.placed.empty());
}

TEST_CASE("restart drill: torn place_submitted with no place_accepted")
{
    // Instance 1 crashed between persisting the place intent and the
    // venue ack: the log ends at place_submitted. Replay leaves a
    // Pending entry; reconciliation decides its fate.
    const auto path = temp_log_path("torn_submitted");
    std::filesystem::remove(path);
    {
        EventLog log{path};
        CHECK_FALSE(log.append({{"type", "place_submitted"},
                                {"clientOrderId", "gw1"},
                                {"symbol", "BTC-USDT"},
                                {"venue", "okx"},
                                {"side", "buy"},
                                {"orderType", "limit"},
                                {"price", "50000"},
                                {"quantity", "2"},
                                {"timeInForce", "GTC"}})
                        .has_value());
    }

    FakeConnector connector;
    EventLog log{path};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
    REQUIRE(oms.load_from_log().is_ok());

    // replay restores the pending entry with its full intent
    const auto pending = oms.query("gw1");
    REQUIRE(pending.is_ok());
    CHECK(pending.value().state == OrderState::Pending);
    CHECK(pending.value().exchange_order_id.empty());
    CHECK(pending.value().symbol == "BTC-USDT");
    CHECK(pending.value().quantity == "2");

    // the unacked id replays pending: no venue re-send
    const auto replayed = oms.place(buy_request("gw1", "2"));
    REQUIRE(replayed.is_ok());
    CHECK(replayed.value().replayed);
    CHECK(replayed.value().record.state == OrderState::Pending);
    REQUIRE(connector.placed.empty());

    // and it cannot be canceled or amended meanwhile
    CHECK(oms.cancel("gw1").error().code == "order_pending");
    CHECK(oms.amend(AmendCommand{"gw1", std::optional<std::string>{"1"}, std::nullopt})
              .error()
              .code == "order_pending");

    const OrderSnapshot venue_state{.client_order_id = "gw1",
                                    .exchange_order_id = "ord-gw1",
                                    .instrument_id = "BTC-USDT",
                                    .state = OrderState::PartiallyFilled,
                                    .side = Side::Buy,
                                    .type = OrderType::Limit,
                                    .price = "50000",
                                    .quantity = "2",
                                    .filled_quantity = "0.7",
                                    .average_fill_price = "49999.5"};

    SUBCASE("found on the venue: snapshot adopts the pending entry forward")
    {
        connector.get_impl =
            [&venue_state](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{venue_state}};
        };
        const auto reconcile_report = oms.reconcile();
        CHECK(reconcile_report.updated == 1);
        const auto record = oms.query("gw1");
        REQUIRE(record.is_ok());
        CHECK(record.value().state == OrderState::PartiallyFilled);
        CHECK(record.value().filled_quantity == "0.7");
        CHECK(record.value().exchange_order_id == "ord-gw1");
    }

    SUBCASE("conclusively absent: Rejected (venue never saw it)")
    {
        connector.get_impl = [](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            return Error{"venue:51603", "Order does not exist"};
        };
        const auto reconcile_report = oms.reconcile();
        CHECK(reconcile_report.absent_rejected == 1);
        const auto record = oms.query("gw1");
        REQUIRE(record.is_ok());
        CHECK(record.value().state == OrderState::Rejected);
        REQUIRE(record.value().rejection.has_value());
        CHECK(record.value().rejection->code == "venue_absent");
        // retries replay the deterministic rejection
        const auto retry = oms.place(buy_request("gw1", "2"));
        REQUIRE_FALSE(retry.is_ok());
        CHECK(retry.error().code == "venue_absent");
    }

    SUBCASE("venue unreachable: kept pending, counted unresolved")
    {
        connector.get_impl = [](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            return Error{"transport", "venue unreachable"};
        };
        const auto reconcile_report = oms.reconcile();
        CHECK(reconcile_report.unresolved == 1);
        const auto record = oms.query("gw1");
        REQUIRE(record.is_ok());
        CHECK(record.value().state == OrderState::Pending); // kept, not guessed
    }
}

TEST_CASE("stats expose registry size and arbitration counters")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request()).is_ok());

    oms.on_execution_report(report("gw1", OrderState::Live, "0"));
    oms.on_execution_report(report("nope", OrderState::Live, "0"));

    const auto stats = oms.stats();
    CHECK(stats.known_orders == 1);
    CHECK(stats.reports_unknown == 1);
    CHECK((stats.reports_applied + stats.reports_stale) == 1);
    CHECK(stats.log_write_failures == 0);
}

TEST_CASE("all_orders snapshots the registry sorted and isolated from mutation")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};

    CHECK(oms.all_orders().empty());

    REQUIRE(oms.place(buy_request("gw2", "1")).is_ok());
    REQUIRE(oms.place(buy_request("gw1", "1")).is_ok());
    oms.on_execution_report(report("gw1", OrderState::Filled, "1", "50000"));

    const auto snapshot = oms.all_orders();
    REQUIRE(snapshot.size() == 2);
    // sorted by clientOrderId, not insertion order
    CHECK(snapshot[0].client_order_id == "gw1");
    CHECK(snapshot[1].client_order_id == "gw2");
    CHECK(snapshot[0].state == OrderState::Filled);
    CHECK(snapshot[1].state == OrderState::Live);

    // the snapshot is a copy: reports applied afterwards do not leak in
    oms.on_execution_report(report("gw2", OrderState::Filled, "1", "50000"));
    CHECK(snapshot[1].state == OrderState::Live);
    CHECK(oms.query("gw2").value().state == OrderState::Filled);
}

TEST_CASE("get_price routes to the resolved venue and reports it")
{
    FakeConnector okx;
    FakeConnector binance;
    OrderManagementSystem oms{{{"okx", &okx}, {"binance", &binance}}, nullptr, RiskConfig{}, "okx"};

    SUBCASE("omitted venue resolves to the default venue")
    {
        const auto quote = oms.get_price("BTC-USDT");
        REQUIRE(quote.is_ok());
        CHECK(quote.value().venue == "okx");
        CHECK(quote.value().price == "fake-BTC-USDT-price");
        CHECK(okx.price_queries.size() == 1);
        CHECK(okx.price_queries.front() == "BTC-USDT");
        CHECK(binance.price_queries.empty());
    }
    SUBCASE("explicit venue routes to that connector")
    {
        const auto quote = oms.get_price("BTC-USDT", "binance");
        REQUIRE(quote.is_ok());
        CHECK(quote.value().venue == "binance");
        CHECK(okx.price_queries.empty());
    }
    SUBCASE("unknown venue is an invalid_request error naming the venue")
    {
        const auto quote = oms.get_price("BTC-USDT", "bybit");
        REQUIRE_FALSE(quote.is_ok());
        CHECK(quote.error().code == "invalid_request");
        CHECK(quote.error().message.find("bybit") != std::string::npos);
    }
    SUBCASE("connector errors pass through untouched")
    {
        binance.price_impl = [](const std::string&) -> Result<std::string> {
            return Error{"transport", "venue unreachable"};
        };
        const auto quote = oms.get_price("BTC-USDT", "binance");
        REQUIRE_FALSE(quote.is_ok());
        CHECK(quote.error().code == "transport");
    }
}

// ---------------------------------------------- versioned legs / amend race ----

TEST_CASE("an amend racing its own cancelReplace reports lands Filled, not a zombie Live")
{
    // The exact production incident: Binance cancelReplace delivers the
    // old leg's CANCELED, the replacement's NEW and its FILLED on the
    // feed thread before the amend response returns. All three must be
    // buffered, then applied after the amended event installs the new
    // leg: the old CANCELED arbitrates superseded, the replacement fills
    // drive the record to Filled.
    const auto path = temp_log_path("amend_race");
    std::filesystem::remove(path);

    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.amend_impl = [&oms_ptr](const AmendRequest& a_request) {
        // the whole venue-side amend plays out before the response lands
        oms_ptr->on_execution_report(report("gw1", OrderState::Canceled, "0"));
        oms_ptr->on_execution_report(ExecutionReport{.client_order_id = "gw1",
                                                     .exchange_order_id = "ord-gw1-repl",
                                                     .state = OrderState::Live,
                                                     .side = Side::Buy,
                                                     .filled_quantity = "0",
                                                     .average_fill_price = ""});
        oms_ptr->on_execution_report(ExecutionReport{.client_order_id = "gw1",
                                                     .exchange_order_id = "ord-gw1-repl",
                                                     .state = OrderState::Filled,
                                                     .side = Side::Buy,
                                                     .filled_quantity = "2",
                                                     .average_fill_price = "79272.01"});
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-gw1-repl"};
    };
    EventLog log{path};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
    oms_ptr = &oms;
    REQUIRE(oms.place(buy_request("gw1", "2")).is_ok()); // leg 1: ord-gw1

    const auto amended = oms.amend(AmendCommand{"gw1", "79291.1", std::nullopt});
    REQUIRE(amended.is_ok());
    CHECK(amended.value().state == OrderState::Filled); // not a zombie Live
    CHECK(amended.value().filled_quantity == "2");
    CHECK(amended.value().average_fill_price == "79272.01");
    CHECK(amended.value().exchange_order_id == "ord-gw1-repl");

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    REQUIRE(record.value().legs.size() == 2);
    CHECK(record.value().legs[0].version == 1);
    CHECK(record.value().legs[0].exchange_order_id == "ord-gw1");
    CHECK(record.value().legs[1].version == 2);
    CHECK(record.value().legs[1].exchange_order_id == "ord-gw1-repl");

    // all three reports passed through the buffer
    CHECK(oms.stats().reports_buffered == 3);

    // replay-correct event order: the amended event precedes the fill state
    std::ifstream file(path);
    std::vector<std::string> order;
    std::string line;
    while (std::getline(file, line)) {
        const auto event = nlohmann::json::parse(line, nullptr, false);
        if (!event.is_discarded() && event.contains("type")) {
            order.push_back(event["type"].get<std::string>());
        }
    }
    const auto amended_at = std::find(order.begin(), order.end(), "amended");
    const auto filled_at = std::find(order.begin(), order.end(), "state");
    REQUIRE(amended_at != order.end());
    REQUIRE(filled_at != order.end());
    CHECK(amended_at < filled_at);

    // and a restart replays the same terminal truth
    FakeConnector replay_connector;
    EventLog replay_log{path};
    OrderManagementSystem recovered{{{"okx", &replay_connector}}, &replay_log, RiskConfig{}};
    REQUIRE(recovered.load_from_log().is_ok());
    const auto replayed = recovered.query("gw1");
    REQUIRE(replayed.is_ok());
    CHECK(replayed.value().state == OrderState::Filled);
    CHECK(replayed.value().filled_quantity == "2");
    REQUIRE(replayed.value().legs.size() == 2);
    CHECK(replayed.value().legs[1].exchange_order_id == "ord-gw1-repl");
}

TEST_CASE("three resting orders amended across the mid all fill instantly")
{
    // Production shape of the "amend to cross" play: three resting buys
    // far below mid are each amended to a crossing price. The venue
    // plays out the whole amend on the feed thread BEFORE the amend
    // response returns: old-leg CANCELED, the replacement going LIVE,
    // the replacement fully FILLED. All three orders must land Filled
    // (never a zombie Live) with their fills, a correct two-leg table
    // and replay-correct event order (amended -> state filled).
    const auto path = temp_log_path("cross_mid");
    std::filesystem::remove(path);

    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.amend_impl = [&oms_ptr](const AmendRequest& a_request) {
        const std::string id = a_request.client_order_id;
        const std::string replacement = "ord-" + id + "-repl";
        // the old resting leg is canceled untouched...
        oms_ptr->on_execution_report(report(id, OrderState::Canceled, "0"));
        // ...the replacement goes live and fills instantly at the cross
        oms_ptr->on_execution_report(ExecutionReport{.client_order_id = id,
                                                     .exchange_order_id = replacement,
                                                     .state = OrderState::Live,
                                                     .side = Side::Buy,
                                                     .filled_quantity = "0",
                                                     .average_fill_price = ""});
        oms_ptr->on_execution_report(ExecutionReport{.client_order_id = id,
                                                     .exchange_order_id = replacement,
                                                     .state = OrderState::Filled,
                                                     .side = Side::Buy,
                                                     .filled_quantity = "1",
                                                     .average_fill_price = "79500"});
        return OrderPlacement{.client_order_id = id, .exchange_order_id = replacement};
    };
    EventLog log{path};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
    oms_ptr = &oms;

    // three resting buys far below the mid
    for (const std::string id : {"gw1", "gw2", "gw3"}) {
        INFO("placing " << id);
        REQUIRE(oms.place(buy_request(id, "1")).is_ok());
    }

    // each is amended across the mid: the ack itself carries the fill
    for (const std::string id : {"gw1", "gw2", "gw3"}) {
        INFO("amending " << id);
        const auto amended = oms.amend(AmendCommand{id, "80000", std::nullopt});
        REQUIRE(amended.is_ok());
        CHECK(amended.value().state == OrderState::Filled); // not a zombie Live
        CHECK(amended.value().filled_quantity == "1");
        CHECK(amended.value().average_fill_price == "79500");
        CHECK(amended.value().price == "80000");
    }

    // registry truth per order: filled, two-leg table, current = replacement
    for (const std::string id : {"gw1", "gw2", "gw3"}) {
        INFO("checking " << id);
        const auto record = oms.query(id);
        REQUIRE(record.is_ok());
        CHECK(record.value().state == OrderState::Filled);
        CHECK(record.value().filled_quantity == "1");
        REQUIRE(record.value().legs.size() == 2);
        CHECK(record.value().legs[0].version == 1);
        CHECK(record.value().legs[0].exchange_order_id == "ord-" + id);
        CHECK(record.value().legs[1].version == 2);
        CHECK(record.value().legs[1].exchange_order_id == "ord-" + id + "-repl");
        CHECK(record.value().exchange_order_id == "ord-" + id + "-repl");
    }

    // all nine reports passed through the race buffer
    CHECK(oms.stats().reports_buffered == 9);

    // the persisted event order is replay-correct per order:
    // place_submitted -> place_accepted -> amended -> state(filled)
    std::ifstream file(path);
    std::map<std::string, std::vector<std::string>> sequence;
    std::string line;
    while (std::getline(file, line)) {
        const auto event = nlohmann::json::parse(line, nullptr, false);
        if (event.is_discarded() || !event.contains("type")) {
            continue;
        }
        sequence[event["clientOrderId"].get<std::string>()].push_back(
            event["type"].get<std::string>());
    }
    for (const auto& [id, types] : sequence) {
        REQUIRE(types.size() == 4);
        CHECK(types[0] == "place_submitted");
        CHECK(types[1] == "place_accepted");
        CHECK(types[2] == "amended");
        CHECK(types[3] == "state");
    }

    // a restart replays the same terminal truth for all three
    FakeConnector replay_connector;
    EventLog replay_log{path};
    OrderManagementSystem recovered{{{"okx", &replay_connector}}, &replay_log, RiskConfig{}};
    REQUIRE(recovered.load_from_log().is_ok());
    for (const std::string id : {"gw1", "gw2", "gw3"}) {
        const auto replayed = recovered.query(id);
        REQUIRE(replayed.is_ok());
        CHECK(replayed.value().state == OrderState::Filled);
        CHECK(replayed.value().filled_quantity == "1");
        REQUIRE(replayed.value().legs.size() == 2);
        CHECK(replayed.value().legs[1].exchange_order_id == "ord-" + id + "-repl");
    }
}

TEST_CASE("a partial fill racing the amend keeps its fills across legs")
{    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.amend_impl = [&oms_ptr](const AmendRequest& a_request) {
        // the old leg partially filled 0.4 before the cancel landed
        oms_ptr->on_execution_report(report("gw1", OrderState::Canceled, "0.4"));
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-gw1-repl"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms_ptr = &oms;
    REQUIRE(oms.place(buy_request("gw1", "2")).is_ok());

    const auto amended = oms.amend(AmendCommand{"gw1", "48000", std::nullopt});
    REQUIRE(amended.is_ok());
    CHECK(amended.value().state == OrderState::Live); // not terminalized
    CHECK(amended.value().filled_quantity == "0.4"); // the fill survived
}

TEST_CASE("an in-place amend advances the version while repeating the id")
{
    // OKX-style amend: the venue echoes the same exchange order id.
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request("gw1", "2")).is_ok());

    REQUIRE(oms.amend(AmendCommand{"gw1", "48000", std::nullopt}).is_ok());
    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    REQUIRE(record.value().legs.size() == 2);
    CHECK(record.value().legs[0].version == 1);
    CHECK(record.value().legs[1].version == 2);
    CHECK(record.value().legs[1].exchange_order_id == "ord-gw1"); // same id

    // reports on that id still drive the full lifecycle (newest match wins)
    oms.on_execution_report(report("gw1", OrderState::PartiallyFilled, "1", "47999"));
    CHECK(oms.query("gw1").value().state == OrderState::PartiallyFilled);
}

TEST_CASE("an amend failing while its replacement provably went live adopts the leg")
{
    // Amend response lost in transport, but the buffered reports show the
    // cancelReplace landed: old CANCELED + replacement LIVE. The record
    // must stay live on the adopted leg instead of terminalizing on the
    // old one.
    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.amend_impl = [&oms_ptr](const AmendRequest&) {
        oms_ptr->on_execution_report(report("gw1", OrderState::Canceled, "0"));
        oms_ptr->on_execution_report(ExecutionReport{.client_order_id = "gw1",
                                                     .exchange_order_id = "ord-gw1-repl",
                                                     .state = OrderState::Live,
                                                     .side = Side::Buy,
                                                     .filled_quantity = "0",
                                                     .average_fill_price = ""});
        return Error{"transport", "amend outcome unresolved"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms_ptr = &oms;
    REQUIRE(oms.place(buy_request()).is_ok());

    const auto failed = oms.amend(AmendCommand{"gw1", "48000", std::nullopt});
    REQUIRE_FALSE(failed.is_ok());
    CHECK(failed.error().code == "transport");

    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Live); // replacement is live
    CHECK(record.value().exchange_order_id == "ord-gw1-repl");
    REQUIRE(record.value().legs.size() == 2);
    CHECK(oms.stats().legs_discovered == 1);
}

TEST_CASE("an amend failing after a real cancel terminalizes as Canceled")
{
    // Partial success: the cancel leg landed, no replacement exists. The
    // old leg's CANCELED is the venue truth and applies in full.
    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.amend_impl = [&oms_ptr](const AmendRequest&) {
        oms_ptr->on_execution_report(report("gw1", OrderState::Canceled, "0"));
        return Error{"venue:-2011",
                     "amend outcome partially unknown: original order is CANCELED"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms_ptr = &oms;
    REQUIRE(oms.place(buy_request()).is_ok());

    const auto failed = oms.amend(AmendCommand{"gw1", "48000", std::nullopt});
    REQUIRE_FALSE(failed.is_ok());
    CHECK(oms.query("gw1").value().state == OrderState::Canceled);
    CHECK(oms.stats().legs_discovered == 0);
}

TEST_CASE("a concurrent amend against an in-flight amend is rejected order_busy")
{
    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    connector.amend_impl = [&oms_ptr](const AmendRequest& a_request) {
        // a second amend arrives while this venue call is open
        const auto racing = oms_ptr->amend(AmendCommand{"gw1", "47000", std::nullopt});
        REQUIRE_FALSE(racing.is_ok());
        CHECK(racing.error().code == "order_busy");
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-gw1-repl"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms_ptr = &oms;
    REQUIRE(oms.place(buy_request()).is_ok());

    REQUIRE(oms.amend(AmendCommand{"gw1", "48000", std::nullopt}).is_ok());
    REQUIRE(connector.amends.size() == 1); // the busy one never reached the venue
}

TEST_CASE("a report carrying an unknown exchange order id is adopted as a new leg")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request("gw1", "2")).is_ok());

    // a replacement we never learned about (lost amend ack)
    oms.on_execution_report(ExecutionReport{.client_order_id = "gw1",
                                            .exchange_order_id = "ord-mystery",
                                            .state = OrderState::PartiallyFilled,
                                            .side = Side::Buy,
                                            .filled_quantity = "1",
                                            .average_fill_price = "48000"});
    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::PartiallyFilled);
    CHECK(record.value().exchange_order_id == "ord-mystery");
    REQUIRE(record.value().legs.size() == 2);
    CHECK(record.value().legs[1].exchange_order_id == "ord-mystery");
    CHECK(oms.stats().legs_discovered == 1);

    // later reports on the superseded original id contribute fills only
    oms.on_execution_report(report("gw1", OrderState::Canceled, "1.5"));
    const auto after = oms.query("gw1");
    REQUIRE(after.is_ok());
    CHECK(after.value().state == OrderState::PartiallyFilled); // not Canceled
    CHECK(after.value().filled_quantity == "1.5");

    // the adoption is surfaced by the audit
    const auto audited = oms.audit();
    const auto found = std::count_if(audited.alerts.begin(), audited.alerts.end(),
                                     [](const ConsistencyAlert& a_alert) {
                                         return a_alert.check == "unknown_leg_report" &&
                                                a_alert.client_order_id == "gw1";
                                     });
    CHECK(found == 1);
}

TEST_CASE("legacy amend events without a version replay with the historic resurrection")
{
    const auto path = temp_log_path("legacy_amend");
    std::filesystem::remove(path);
    {
        EventLog log{path};
        // pre-versioning log shape: the runtime bug wrote canceled before
        // an amended(state=live) that had to resurrect the record
        CHECK_FALSE(log.append({{"type", "place_accepted"},
                                {"clientOrderId", "gw1"},
                                {"symbol", "BTC-USDT"},
                                {"venue", "okx"},
                                {"side", "buy"},
                                {"orderType", "limit"},
                                {"price", "50000"},
                                {"quantity", "1"},
                                {"timeInForce", "GTC"},
                                {"exchangeOrderId", "ord-gw1"}})
                         .has_value());
        CHECK_FALSE(
            log.append({{"type", "state"},
                        {"clientOrderId", "gw1"},
                        {"state", "canceled"},
                        {"filledQuantity", "0"},
                        {"averageFillPrice", ""},
                        {"exchangeOrderId", "ord-gw1"}})
                .has_value());
        CHECK_FALSE(log.append({{"type", "amended"},
                                {"clientOrderId", "gw1"},
                                {"price", "48000"},
                                {"quantity", "1"},
                                {"state", "live"},
                                {"exchangeOrderId", "ord-gw1-repl"}})
                         .has_value());
    }

    FakeConnector connector;
    EventLog log{path};
    OrderManagementSystem oms{{{"okx", &connector}}, &log, RiskConfig{}};
    REQUIRE(oms.load_from_log().is_ok());
    const auto record = oms.query("gw1");
    REQUIRE(record.is_ok());
    CHECK(record.value().state == OrderState::Live); // resurrected, as before
    REQUIRE(record.value().legs.size() == 2);
    CHECK(record.value().legs[0].exchange_order_id == "ord-gw1");
    CHECK(record.value().legs[1].exchange_order_id == "ord-gw1-repl");
}

// ------------------------------------------------------------------ audit ----

TEST_CASE("audit flags a fill/state zombie without healing it")
{
    FakeConnector connector;
    connector.get_impl = [](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
        return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{std::nullopt}};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request("gw1", "1")).is_ok());

    // a venue reporting a full fill as a mere partial: the registry keeps
    // it, the audit must call it out
    oms.on_execution_report(report("gw1", OrderState::PartiallyFilled, "1", "50000"));

    const auto before = oms.query("gw1");
    REQUIRE(before.is_ok());
    CHECK(before.value().state == OrderState::PartiallyFilled);

    const auto audited = oms.audit();
    const auto found = std::count_if(audited.alerts.begin(), audited.alerts.end(),
                                     [](const ConsistencyAlert& a_alert) {
                                         return a_alert.check == "fill_state_mismatch" &&
                                                a_alert.client_order_id == "gw1";
                                     });
    CHECK(found == 1);

    // alert-only: nothing was repaired
    const auto after = oms.query("gw1");
    REQUIRE(after.is_ok());
    CHECK(after.value().state == OrderState::PartiallyFilled);
    CHECK(after.value().filled_quantity == "1");
}

TEST_CASE("audit compares non-terminal orders against venue truth")
{
    FakeConnector connector;
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    REQUIRE(oms.place(buy_request("gw1", "1")).is_ok()); // local: live, 0 filled

    const OrderSnapshot venue_snapshot{.client_order_id = "gw1",
                                       .exchange_order_id = "ord-gw1",
                                       .instrument_id = "BTC-USDT",
                                       .state = OrderState::PartiallyFilled,
                                       .side = Side::Buy,
                                       .type = OrderType::Limit,
                                       .price = "49000.00000000", // venue zero padding
                                       .quantity = "1",
                                       .filled_quantity = "0.5",
                                       .average_fill_price = "49100"};

    SUBCASE("drift on state, fills and price is reported")
    {
        connector.get_impl =
            [&venue_snapshot](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            return Result<std::optional<OrderSnapshot>>{
                std::optional<OrderSnapshot>{venue_snapshot}};
        };
        const auto audited = oms.audit();
        CHECK(audited.orders_checked == 1);
        CHECK(audited.venue_lookups == 1);
        const auto has = [&audited](const char* a_check) {
            return std::any_of(audited.alerts.begin(), audited.alerts.end(),
                               [a_check](const ConsistencyAlert& a_alert) {
                                   return a_alert.check == a_check &&
                                          a_alert.client_order_id == "gw1";
                               });
        };
        CHECK(has("state_mismatch"));          // live vs partially_filled
        CHECK(has("fill_mismatch"));           // 0 vs 0.5
        CHECK(has("price_qty_mismatch"));      // 50000 vs 49000
        CHECK_FALSE(has("venue_unknown"));
    }

    SUBCASE("venue zero padding is not drift")
    {
        const OrderSnapshot padded{.client_order_id = "gw1",
                                   .exchange_order_id = "ord-gw1",
                                   .instrument_id = "BTC-USDT",
                                   .state = OrderState::Live,
                                   .side = Side::Buy,
                                   .type = OrderType::Limit,
                                   .price = "50000.00000000",
                                   .quantity = "1.00000000",
                                   .filled_quantity = "0.0",
                                   .average_fill_price = ""};
        connector.get_impl = [&padded](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{padded}};
        };
        const auto audited = oms.audit();
        CHECK(audited.alerts.empty());
    }

    SUBCASE("venue-unknown non-terminal orders are reported")
    {
        connector.get_impl = [](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{std::nullopt}};
        };
        const auto audited = oms.audit();
        REQUIRE(audited.alerts.size() == 1);
        CHECK(audited.alerts[0].check == "venue_unknown");
        CHECK(audited.alerts[0].client_order_id == "gw1");
    }

    SUBCASE("failing lookups are counted and reported, state untouched")
    {
        connector.get_impl = [](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            return Error{"transport", "venue unreachable"};
        };
        const auto audited = oms.audit();
        CHECK(audited.lookup_failures == 1);
        REQUIRE(audited.alerts.size() == 1);
        CHECK(audited.alerts[0].check == "lookup_failed");
        CHECK(oms.query("gw1").value().state == OrderState::Live);
    }

    SUBCASE("terminal orders are not looked up at all")
    {
        oms.on_execution_report(report("gw1", OrderState::Filled, "1", "50000"));
        std::size_t lookups = 0;
        connector.get_impl = [&](const OrderQuery&) -> Result<std::optional<OrderSnapshot>> {
            ++lookups;
            return Result<std::optional<OrderSnapshot>>{std::optional<OrderSnapshot>{std::nullopt}};
        };
        const auto audited = oms.audit();
        CHECK(audited.venue_lookups == 0);
        CHECK(lookups == 0);
    }
}

TEST_CASE("audit skips orders whose amend venue call is still open")
{
    FakeConnector connector;
    OrderManagementSystem* oms_ptr = nullptr;
    AuditReport mid_flight;
    connector.amend_impl = [&oms_ptr, &mid_flight](const AmendRequest& a_request) {
        // the audit runs while this amend's venue call is open: the order
        // must be skipped (its own ack path owns it)
        mid_flight = oms_ptr->audit();
        return OrderPlacement{.client_order_id = a_request.client_order_id,
                              .exchange_order_id = "ord-gw1-repl"};
    };
    OrderManagementSystem oms{{{"okx", &connector}}, nullptr, RiskConfig{}};
    oms_ptr = &oms;
    REQUIRE(oms.place(buy_request()).is_ok());

    REQUIRE(oms.amend(AmendCommand{"gw1", "48000", std::nullopt}).is_ok());
    CHECK(mid_flight.orders_checked == 1);
    CHECK(mid_flight.venue_lookups == 0); // skipped, not compared mid-flight
}

} // namespace
