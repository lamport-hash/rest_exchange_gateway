#pragma once

#include "gateway/result.hpp"

#include <cctype>
#include <cstddef>
#include <functional>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace gateway {

/// Order side, normalized across venues.
enum class Side
{
    Buy,
    Sell
};

/// Supported order types (venue-specific types are intentionally rejected).
enum class OrderType
{
    Limit,
    Market
};

/// Normalized order lifecycle state. Illegal transitions are a concern of
/// the order state machine (later phase); connectors only report snapshots.
///
/// Pending is gateway-local: it marks a place the gateway has staged and
/// sent but the venue has not acknowledged yet. Venue execution reports
/// and snapshots NEVER carry Pending; only the OMS creates it (at place
/// staging) and only venue observations (or restart reconciliation)
/// resolve it.
enum class OrderState
{
    Pending,
    Live,
    PartiallyFilled,
    Filled,
    Canceled,
    Rejected
};

/// Client-facing order request. price/quantity are decimal strings carried
/// verbatim to the venue (no float conversion). time_in_force is the
/// normalized "GTC"/"IOC"/"FOK" (empty = venue default).
struct OrderRequest
{
    std::string client_order_id;
    std::string instrument_id;
    Side side = Side::Buy;
    OrderType type = OrderType::Limit;
    std::string price;
    std::string quantity;
    std::string time_in_force;
};

struct CancelRequest
{
    std::string client_order_id;
    std::string instrument_id;
};

struct OrderQuery
{
    std::string client_order_id;
    std::string instrument_id;
};

struct AmendRequest
{
    std::string client_order_id;
    std::string instrument_id;
    std::optional<std::string> new_price;
    std::optional<std::string> new_quantity;
    /// Attributes of the RESULTING order, needed only by venues whose
    /// amend is a cancel+replace (Binance); in-place amend venues (OKX)
    /// ignore them. Callers that know the original order should always
    /// provide them.
    std::optional<Side> side;
    std::optional<OrderType> type;
    std::string time_in_force;
};

/// Acknowledgement of place/cancel/amend: venue accepted the request.
struct OrderPlacement
{
    std::string client_order_id;
    std::string exchange_order_id;
};

/// Full normalized snapshot of an order as reported by the venue.
struct OrderSnapshot
{
    std::string client_order_id;
    std::string exchange_order_id;
    /// Venue instrument id (same spelling the client used, e.g. BTC-USDT);
    /// needed to adopt venue-live orders during reconciliation.
    std::string instrument_id;
    OrderState state = OrderState::Live;
    Side side = Side::Buy;
    OrderType type = OrderType::Limit;
    std::string price;
    std::string quantity;
    std::string filled_quantity;
    std::string average_fill_price;
};

/// Incremental execution update (WebSocket phase); delivered off the
/// connector's worker threads.
struct ExecutionReport
{
    std::string client_order_id;
    std::string exchange_order_id;
    OrderState state = OrderState::Live;
    Side side = Side::Buy;
    std::string filled_quantity;
    std::string average_fill_price;
};

/// Venue-agnostic trading interface implemented by every exchange adapter.
/// All methods are synchronous in phase 1 (REST) and may fail with Result
/// errors: "transport" (network), "protocol" (malformed venue data),
/// "venue:<code>" (venue rejection). Thread-safety: implementations must be
/// safe to call from the REST worker threads.
class ExchangeConnector
{
  public:
    virtual ~ExchangeConnector() = default;

  protected:
    ExchangeConnector() = default;

  public:
    ExchangeConnector(const ExchangeConnector&) = delete;
    auto operator=(const ExchangeConnector&) -> ExchangeConnector& = delete;

    /// Place a new order. Returns the venue's order id mapping on success.
    [[nodiscard]] virtual auto
    place_order(const OrderRequest& a_request) -> Result<OrderPlacement> = 0;

    /// Cancel an open order.
    [[nodiscard]] virtual auto
    cancel_order(const CancelRequest& a_request) -> Result<OrderPlacement> = 0;

    /// Amend an open order (price and/or quantity). Venues without a native
    /// amend emulate it in their adapter.
    [[nodiscard]] virtual auto
    amend_order(const AmendRequest& a_request) -> Result<OrderPlacement> = 0;

    /// Fetch the current snapshot. std::nullopt means the venue does not
    /// know the order (never placed, or aged out).
    [[nodiscard]] virtual auto
    get_order(const OrderQuery& a_query) -> Result<std::optional<OrderSnapshot>> = 0;

    /// All currently open (working) orders on the venue, e.g. OKX
    /// GET /api/v5/trade/orders-pending. Used by startup/reconnect
    /// reconciliation to adopt venue-live orders missing from the local
    /// registry. Best effort: implementations may return a single page
    /// and skip items they cannot normalize.
    [[nodiscard]] virtual auto get_open_orders() -> Result<std::vector<OrderSnapshot>> = 0;

    /// Last-traded price of an instrument (public market data, decimal
    /// string as reported by the venue). Errors: "transport", "protocol",
    /// "venue:<code>" (e.g. unknown instrument).
    [[nodiscard]] virtual auto
    get_price(const std::string& a_instrument_id) -> Result<std::string> = 0;

    /// Register the execution-report sink (WebSocket-driven updates). Must
    /// be installed before start(); reports are delivered on connector-owned
    /// threads.
    virtual void
    set_execution_report_handler(std::function<void(const ExecutionReport&)> a_handler) = 0;

    /// Register the execution-feed connectivity sink: invoked with true
    /// when the feed (re)establishes, false when it drops. Lets the core
    /// re-reconcile state that may have been missed during an outage.
    /// Must be installed before start().
    virtual void set_connectivity_handler(std::function<void(bool)> a_handler) = 0;

    /// Begin background work (execution feeds). Handlers must be installed
    /// beforehand. Idempotent.
    virtual void start() = 0;

    /// Stop background work, close feeds and join connector-owned threads.
    /// Idempotent; synchronous requests may still be used afterwards.
    virtual void stop() = 0;
};

/// Lower-case name of a state for logging/responses, e.g. "partially_filled".
[[nodiscard]] inline auto to_string(OrderState a_state) -> std::string_view
{
    switch (a_state) {
    case OrderState::Pending:
        return "pending";
    case OrderState::Live:
        return "live";
    case OrderState::PartiallyFilled:
        return "partially_filled";
    case OrderState::Filled:
        return "filled";
    case OrderState::Canceled:
        return "canceled";
    case OrderState::Rejected:
        return "rejected";
    }
    return "unknown";
}

/// Lower-case name of a side ("buy"/"sell").
[[nodiscard]] inline auto to_string(Side a_side) -> std::string_view
{
    return a_side == Side::Buy ? "buy" : "sell";
}

/// Lower-case name of an order type ("limit"/"market").
[[nodiscard]] inline auto to_string(OrderType a_type) -> std::string_view
{
    return a_type == OrderType::Limit ? "limit" : "market";
}

/// ASCII case-insensitive equality of two views (locale-independent).
[[nodiscard]] inline auto equals_ignore_case(std::string_view a_lhs, std::string_view a_rhs) -> bool
{
    if (a_lhs.size() != a_rhs.size()) {
        return false;
    }
    for (std::size_t index = 0; index < a_lhs.size(); ++index) {
        if (std::tolower(static_cast<unsigned char>(a_lhs[index])) !=
            std::tolower(static_cast<unsigned char>(a_rhs[index]))) {
            return false;
        }
    }
    return true;
}

/// Case-insensitive inverse of to_string(Side). std::nullopt for any
/// other spelling.
[[nodiscard]] inline auto parse_side(std::string_view a_text) -> std::optional<Side>
{
    if (equals_ignore_case(a_text, "buy")) {
        return Side::Buy;
    }
    if (equals_ignore_case(a_text, "sell")) {
        return Side::Sell;
    }
    return std::nullopt;
}

/// Case-insensitive inverse of to_string(OrderType). std::nullopt for
/// any other spelling.
[[nodiscard]] inline auto parse_order_type(std::string_view a_text) -> std::optional<OrderType>
{
    if (equals_ignore_case(a_text, "limit")) {
        return OrderType::Limit;
    }
    if (equals_ignore_case(a_text, "market")) {
        return OrderType::Market;
    }
    return std::nullopt;
}

/// Case-insensitive inverse of to_string(OrderState). "pending" is a
/// valid gateway-local state (round-trips); venue observations never
/// carry it. std::nullopt for any other spelling.
[[nodiscard]] inline auto parse_order_state(std::string_view a_text) -> std::optional<OrderState>
{
    if (equals_ignore_case(a_text, "pending")) {
        return OrderState::Pending;
    }
    if (equals_ignore_case(a_text, "live")) {
        return OrderState::Live;
    }
    if (equals_ignore_case(a_text, "partially_filled")) {
        return OrderState::PartiallyFilled;
    }
    if (equals_ignore_case(a_text, "filled")) {
        return OrderState::Filled;
    }
    if (equals_ignore_case(a_text, "canceled")) {
        return OrderState::Canceled;
    }
    if (equals_ignore_case(a_text, "rejected")) {
        return OrderState::Rejected;
    }
    return std::nullopt;
}

} // namespace gateway
